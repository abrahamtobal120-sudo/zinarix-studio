# Projecting Copilot Managed Settings into VS Code

How enterprise managed settings feed VS Code's existing policy stack. Use only after [SKILL.md](./SKILL.md) routes a control to VS Code. Runtime-only managed settings need no VS Code constant, policy, or export; see [sdk-runtime-policy.md](./sdk-runtime-policy.md).

Key source: `src/vs/platform/policy/common/copilotManagedSettings.ts` (key constants, normalizer, projection, channel merge, shared `value` callbacks).

## The bag

All channels normalize into one bag, `IPolicyData.managedSettings` (`ManagedSettingsData`), which `AccountPolicyService` hands to each policy's `value(policyData)`. There is no separate `IPolicyService`.

- Keys are flat dot-paths (`permissions.disableBypassPermissionsMode`); values are `string | number | boolean`.
- Object/array settings (`enabledPlugins`, `extraKnownMarketplaces`, …) are carried as a JSON string under one key, the same shape admins author in MDM.

## Channels and precedence

| Channel | Implementation |
|---|---|
| Native MDM (Windows registry `SOFTWARE\Policies\GitHubCopilot`, macOS `com.github.copilot`) | `NativeManagedSettingsService` via `@vscode/policy-watcher`; desktop main only, IPC to renderer |
| Server (`/copilot_internal/managed_settings`) | `adaptManagedSettings` → `DefaultAccountService.policyData` |
| File (`managed-settings.json` at per-OS `MANAGED_SETTINGS_*` paths) | `FileManagedSettingsService`; main process, IPC to renderer |

`pickManagedSettings` merges **per key**: native MDM > server > file; lower channels fill keys higher ones leave unset. To add a channel, extend `ManagedSettingsChannel`, `MANAGED_SETTINGS_CHANNELS`, and `pickManagedSettings` together.

`telemetry` and `communication` are whole blocks: the strongest channel that supplies the block wins entirely, and an empty block masks weaker ones, matching the runtime. `communication.support.url` is informational, never counts as governance, and is read only through `getManagedSupportUrl`, which accepts absolute `http`/`https` URLs. Show it as a **Contact Admin** action, or link the "Contact your administrator" sentence to it, without repeating that sentence on the same line, and name its host in a tooltip so it is not mistaken for VS Code or GitHub help. Without a valid URL there is no default help page: keep whatever the surface did before, such as the model picker's link to GitHub's Copilot settings or the Remote Connections **View Setting** action. Open it externally through the opener service so the link-protection prompt still applies; never use it in place of enforcement.

Sandbox exceptions follow runtime composition: `sandbox.enabled` is force-on-wins (`true` anywhere wins); `sandbox.allowBypass` and `sandbox.userPolicy.network.allowOutbound` are deny-wins. The runtime's `x-composition` across enterprise/org/user layers is already collapsed before VS Code sees the bag.

`SandboxSettingsResolutionHelper` shares sandbox presentation rules with Agent Host's effective configuration: managed denials lock the corresponding `chat.agent.sandbox.*` controls; a present managed host or filesystem grant list (including `[]`) replaces the local list; block/denied lists combine local and managed entries. Malformed managed lists leave the local value editable. Stored user preferences are never rewritten.

## Schema

The authority is `copilot-agent-runtime/schema/managed-settings-schema.json` (nested; VS Code flattens it). It contains many runtime-owned keys VS Code never projects. Known gaps and special cases:

- `extraKnownMarketplaces`: VS Code accepts only `github`/`git` sources; `directory` and others are dropped with a warning.
- `strictKnownMarketplaces`: managed-only (no setting or policy), declared in `MANAGED_SETTINGS_CONTROL_DEFINITIONS` and enforced via `IPluginMarketplaceService`. Absent = all allowed; `[]` = lockdown. It governs installation, not already-installed plugins; `chat.plugins.strictMarketplaces` user values are ignored.
- `model` supersedes legacy `permissions.model` across channels; resolve that in the callback (`managedModelValue`), and declare both keys.

## Declaring a key on a policy

```ts
policy: {
	name: 'ChatEnabledPlugins', // chat.plugins.enabledPlugins (setting type: object)
	// ...
	value: managedSettingValue(COPILOT_ENABLED_PLUGINS_KEY),
	managedSettings: { [COPILOT_ENABLED_PLUGINS_KEY]: { type: 'string' } },
}
```

1. Add a key constant in `copilotManagedSettings.ts` that exactly matches the schema; never inline key strings.
2. Declare it in `managedSettings` with its bag type. Use `managedSettingValue(KEY)` for pass-through (memoized, preserving definition identity); hand-write the callback only to combine conditions. Callbacks must be pure; attribution evaluates them more than once.
3. Structured settings must declare `{ type: 'string' }`; `projectManagedSettings` drops values whose `typeof` mismatches (silently ignoring the setting), and `PolicyConfiguration` parses the JSON back. Add one row to `STRUCTURED_MANAGED_SETTINGS` and the field on `IManagedSettingsResponse`.
4. Controls with no governing setting go in `MANAGED_SETTINGS_CONTROL_DEFINITIONS` (always watched by native MDM, never projected) and need no policy export.
5. Export and test per [vscode-policy.md](./vscode-policy.md).

Policy-only settings use `included: false` (for example `chat.plugins.extraMarketplaces`).

## Transport control: `forceRemoteSettingsRefresh`

When effective (resolved across all channels, MDM first), only a fresh successful server response for the current account, auth provider, and endpoint unlocks AI features at startup or on scope change. Failures keep cached restrictions and keep AI disabled until a retry succeeds; authentication stays available. Once satisfied, same-scope background refreshes keep the accepted policy until a response arrives; a failure closes the gate. Chat keeps its selected mode while gated and rechecks the gate before dispatch.

## Governance presence and third-party harnesses

`IPolicyData.managedSettingsActive` is `true` when any channel supplies managed governance, independent of which keys VS Code declares. `thirdPartyAgentEnabledValue(harness)` (used by `Claude3PIntegration`/`Codex3PIntegration`) forces those harnesses off when preview features are disabled, governance is active, or `vscode.temporaryAllowLocalHarness` is `false`, because managed settings never reach Claude or Codex. The harness permissions `vscode.temporaryAllowLocalHarness` and `vscode.allowedHarnesses` never count as governance; empty or control-only server responses clear a cached governance flag.

### Permitting Claude and Codex: `vscode.allowedHarnesses`

An administrator who accepts that boundary can permit one or both third-party harnesses while keeping managed settings for Copilot:

```json
{ "vscode": { "allowedHarnesses": ["claude", "codex"] } }
```

- The list covers only `claude` and `codex`. Copilot and Local are unaffected.
- Absent, governance presence disables both, as before. A present list replaces that block: it permits the harnesses it names and denies the others, so `[]` denies both, with or without other managed settings.
- A permitted harness is exempt from the presence block only. The callback returns `undefined`, never `true`, so user settings, rollout defaults, editor preferences, and SDK availability still decide whether it is offered, and device policy, account and AI gates, the preview-features restriction, and `vscode.temporaryAllowLocalHarness: false` still deny it.
- **Permitting a harness does not govern it.** Claude and Codex do not receive or enforce Copilot runtime managed settings (permissions, sandbox, MCP and plugin controls, telemetry). The list records that the administrator accepts this; it does not extend enforcement.
- IDs are exact lowercase. Entries that are not one of those IDs are ignored instead of invalidating the list, so a list can name a harness that only newer clients know without older clients denying `claude` and `codex`. A list with no recognized entry therefore denies both, like `[]`: `["Claude"]` permits nothing. Duplicates are harmless.
- A value that is not an array is invalid and permits nothing. An invalid value and ignored entries each log one warning naming the key but not the value.
- The list is one structured key, so the highest-precedence channel that supplies it wins outright: lists are never unioned, and an invalid value still masks a weaker channel's list. Server and file carry the array; native MDM carries it as a JSON string.

Server delivery depends on the shared managed-settings schema declaring the key. Check that before relying on the server channel; the file and native MDM channels do not depend on it.

## Diagnostics

**Developer: Policy Diagnostics** shows each channel's raw input → normalized bag → projection, then per-key precedence and the final bag. It separately shows the runtime's own sessionless `managedSettings.resolve()` snapshot, which excludes session-local contributions and does not prove a fresh fetch.

Tests: `copilotManagedSettings.test.ts`, `nativeManagedSettingsService.test.ts`, `fileManagedSettingsService.test.ts`, `accountPolicyService.test.ts`, `defaultAccount.test.ts`, `managedSettings.test.ts` (server/MDM equivalence).
